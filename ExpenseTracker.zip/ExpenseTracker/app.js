const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = require("./models/user");
const Income = require("./models/income");
const Expense = require("./models/expense");
const Budget = require("./models/budget");

const app = express();

app.use(express.json());

mongoose
  .connect("mongodb://127.0.0.1:27017/expensetrackerdb")
  .then(() => {
    console.log("MongoDB Connected");
  })
  .catch((err) => {
    console.log(err);
  });

app.get("/", (req, res) => {
  res.send("Expense Tracker API Running");
});

app.post("/api/auth/signup", async (req, res) => {
  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);

    const user = await User.create({
      name: req.body.name,
      email: req.body.email,
      password: hashedPassword,
    });

    res.status(201).json(user);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const user = await User.findOne({
      email: req.body.email,
    });

    if (!user) {
      return res.status(404).json({
        message: "User not found",
      });
    }

    const validPassword = await bcrypt.compare(
      req.body.password,
      user.password,
    );

    if (!validPassword) {
      return res.status(401).json({
        message: "Invalid Password",
      });
    }

    const token = jwt.sign(
      {
        id: user._id,
      },
      "expenseSecret",
    );

    res.json({
      token,
    });
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.post("/api/income", async (req, res) => {
  try {
    const income = await Income.create({
      source: req.body.source,
      amount: req.body.amount,
    });

    res.status(201).json(income);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.get("/api/income", async (req, res) => {
  try {
    const incomes = await Income.find();

    res.json(incomes);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.put("/api/income/:id", async (req, res) => {
  try {
    const income = await Income.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });

    res.json(income);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.delete("/api/income/:id", async (req, res) => {
  try {
    await Income.findByIdAndDelete(req.params.id);

    res.json({
      message: "Income Deleted Successfully",
    });
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.post("/api/expense", async (req, res) => {
  try {
    const expense = await Expense.create({
      itemName: req.body.itemName,
      category: req.body.category,
      amount: req.body.amount,
    });

    res.status(201).json(expense);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.get("/api/expense", async (req, res) => {
  try {
    const expenses = await Expense.find();

    res.json(expenses);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.put("/api/expense/:id", async (req, res) => {
  try {
    const expense = await Expense.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });

    res.json(expense);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.delete("/api/expense/:id", async (req, res) => {
  try {
    await Expense.findByIdAndDelete(req.params.id);

    res.json({
      message: "Expense Deleted Successfully",
    });
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.post("/api/budget", async (req, res) => {
  try {
    const budget = await Budget.create({
      category: req.body.category,
      limit: req.body.limit,
    });

    res.status(201).json(budget);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.get("/api/metrics/savings", async (req, res) => {
  try {
    const incomeData = await Income.aggregate([
      {
        $group: {
          _id: null,
          totalIncome: {
            $sum: "$amount",
          },
        },
      },
    ]);

    const expenseData = await Expense.aggregate([
      {
        $group: {
          _id: null,
          totalExpense: {
            $sum: "$amount",
          },
        },
      },
    ]);

    const totalIncome = incomeData.length > 0 ? incomeData[0].totalIncome : 0;

    const totalExpense =
      expenseData.length > 0 ? expenseData[0].totalExpense : 0;

    res.json({
      totalIncome,
      totalExpense,
      savings: totalIncome - totalExpense,
    });
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.get("/api/metrics/top-spending", async (req, res) => {
  try {
    const result = await Expense.aggregate([
      {
        $group: {
          _id: "$category",
          totalAmount: {
            $sum: "$amount",
          },
        },
      },
      {
        $sort: {
          totalAmount: -1,
        },
      },
    ]);

    res.json(result);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

app.listen(5000, () => {
  console.log("Server Running On Port 5000");
});
